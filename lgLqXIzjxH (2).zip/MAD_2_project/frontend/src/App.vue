<script setup>
import { RouterLink, RouterView } from 'vue-router'
</script>

<template>
  <RouterView />
</template>

<style>
body {
  padding-left: 15px;
  padding-right: 15px;
}
</style>
