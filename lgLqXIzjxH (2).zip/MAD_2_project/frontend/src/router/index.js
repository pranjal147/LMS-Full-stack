import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'home',
      component: HomeView
    },
    {
      path: '/register',
      name: 'signup',
      component: () => import('../views/SignUp.vue')
    },
    {
      path: '/login',
      name: 'login',
      component: () => import('../views/LogIn.vue')
    },
    {
      path: '/admin',
      name: 'admin',
      component: () => import('../views/AdminDashboard.vue')
    },
    {
      path: '/admin/sections',
      name: 'section',
      component: () => import('../views/Section.vue')
    },
    {
      path: '/admin/add_section',
      name: 'add_section',
      component: () => import('../views/AddSection.vue')
    },
    {
      path: '/admin/update_section/:id',
      name: 'update_section',
      component: () => import('../views/UpdateSection.vue')
    },
    {
      path: '/admin/books',
      name: 'books',
      component: () => import('../views/Book.vue')
    },
    {
      path: '/admin/add_books',
      name: 'add_books',
      component: () => import('../views/AddBooks.vue')
    },
    {
      path: '/admin/update_book/:id',
      name: 'update_book',
      component: () => import('../views/UpdateBook.vue')
    },
    {
      path: '/books',
      name: 'view_books',
      component: () => import('../views/ViewBook.vue')
    },
    {
      path: '/sections',
      name: 'view_sections',
      component: () => import('../views/ViewSection.vue')
    },
    {
      path: '/section_books/:id',
      name: 'section_books',
      component: () => import('../views/SectionBooks.vue')
    },
    {
      path: '/book_detail/:id',
      name: 'book_detail',
      component: () => import('../views/BookDetail.vue')
    },
    {
      path: '/my_books',
      name: 'my_books',
      component: () => import('../views/UserBooks.vue')
    },
    {
      path: '/search',
      name: 'search_results',
      component: () => import('../views/SearchResults.vue')
    },
    {
      path: '/admin/requests',
      name: 'admin_request',
      component: () => import('../views/Request.vue')
    },
    {
      path: '/admin/revoke_access',
      name: 'revoke_access',
      component: () => import('../views/RevokeAccess.vue')
    },
    {
      path: '/read_book/:pdf',
      name: 'readbook',
      component: () => import('../views/BookPDF.vue')
    },
    {
      path: '/feedback/:id',
      name: 'feedback',
      component: () => import('../views/Feedback.vue')
    }
  ]
})

export default router
