<template>
    <div>
      <nav class="navbar navbar-expand-lg top bg-body-primary">
        <a class="navbar-brand" href="/">Library</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#navbarOffcanvasLg" aria-controls="navbarOffcanvasLg" style="border:0px; outline: none;">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-start" tabindex="-1" id="navbarOffcanvasLg" aria-labelledby="navbarOffcanvasLgLabel">
          <div class="offcanvas-header">
            <h5 class="offcanvas-title" id="offcanvasNavbarLabel">My Grocery Store</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" aria-label="Close"></button>
          </div>
          <div class="offcanvas-body">
            <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
              <li class="nav-item">
                <router-link to="/" class="nav-link" exact>Home</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/books" class="nav-link">Books</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/sections" class="nav-link">Sections</router-link>
              </li>
              <li class="nav-item">
                <router-link to="/my_books" class="nav-link">My Books</router-link>
              </li>
              <form class="d-flex" @submit.prevent="search">
                <input v-model="searchQuery" class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-success" type="submit">Search</button>
              </form>
              <li v-if="currentUser.role === 'admin'" class="nav-item">
                <router-link to="/admin" class="nav-link">Admin Dashboard</router-link>
              </li>
              <li v-if="loggedIn === true" class="nav-item">
                <span class="nav-link disabled">Hello {{ currentUser.name }}</span>
              </li>
            </ul>
            <div v-if="!loggedIn">
              <router-link to="/login">  
                <button  class="btn btn-outline-primary">Log In</button>
              </router-link>
            </div>
            <div v-else>
              <button  @click="logout" class="btn btn-outline-primary">Logout</button>
            </div>
          </div>
        </div>
      </nav> 
    <br>
    </div>
</template>
  
<script>
export default {
  name: 'NavBar',
  data() {
    return {
      loggedIn: false,
      currentUser: {},
      searchQuery: null
    }
  },
  mounted() {
    this.loadPage();
  },
  methods: {
    async loadPage() {
      const token = localStorage.getItem('auth_token')
      if (token) {
        try {
          const res = await fetch('http://localhost:5000/identity', {
            headers: {
              'Authorization': `Bearer ${token}`
            }
          })
          if (res.ok) {
            const userDetail = await res.json();
            this.loggedIn = true;
            this.currentUser = userDetail;
          } else {
            console.error('Failed to fetch user details');
          }
        } catch (error) {
          console.error('Error fetching user details:', error);
        }
      }
    },
    search() {
        this.$router.push( { name: 'search_results', query: {q : this.searchQuery} })
    },
    async logout() {
      const token = localStorage.getItem('auth_token')
      fetch('http://localhost:5000/logout').then((res) => {
        if (res.ok) {
          localStorage.removeItem('auth_token')
          this.$router.push({ name: 'login' })
        }
      }).catch((error) => {
        console.error('Error logging out:', error);
      });
    }
  }
}
</script>
