<template>
    <div class="container mt-3">
      <h3>Books</h3> <br>
      <div class="grid">
        <div v-for="book in books" :key="book.b_id">
        <router-link :to="{name: 'book_detail', params: {id: book.b_id}}" id="link">
          <div class="card" style="width:300px; height:500px;">
            <img :src="'http://localhost:5000/static/upload/' + book.image" class="card-img-top" alt="..." height="300px">
            <div class="card-body">
              <h2>{{ book.b_name }}</h2>
              <p class="card-text text-truncate">{{ book.description }}</p>
              <p class="card-text">{{ book.a_name }}</p>
            </div>
          </div>
        </router-link>
        </div>
      </div>
    </div>
</template>

<script>
export default {
    name: 'BookView',
    data() {
      return {
        books: null
      }
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/api/books')
        if (response.ok) {
          const res = await response.json()
          this.books = res
        }
      }
    },
    async mounted() {
        this.load_page()
    }
}
</script>


<style scoped>
    .grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    #link {
        text-decoration: none;
    }
</style>