<template>
    <div class="container mt-3">
      <h3>Sections</h3> <br>
      <div class="grid">
        <div v-for="sec in sections" :key="sec.s_id">
        <router-link :to="{name: 'section_books', params: {id: sec.s_id}}" id="link">
          <div class="card" style="width:300px; height:450px">
            <img :src="'http://localhost:5000/static/upload/' + sec.image" class="card-img-top" alt="..." height="300px">
            <div class="card-body">
              <h2>{{ sec.s_name }}</h2>
              <p class="card-text text-truncate">{{ sec.description }}</p>
            </div>
          </div>
        </router-link>
        </div>
      </div>
    </div>
</template>

<script>

export default {
    name: 'SectionView',
    data() {
      return {
        sections: null
      }
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/api/sections')
        if (response.ok) {
          const res = await response.json()
          this.sections = res
        }
      }
    },
    async mounted() {
        this.load_page()
    }
}
</script>


<style scoped>
    .grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    #link {
        text-decoration: none;
    }
</style>