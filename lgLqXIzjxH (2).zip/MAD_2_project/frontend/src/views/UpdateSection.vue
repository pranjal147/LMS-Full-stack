<template>
    <NavBar></NavBar>
    <div class="row g-3 align-items-center">
        <label for="s_name">Section Name</label>
        <input type="text" id="s_name" name="s_name" v-model="section.s_name" class="form-control" placeholder="Enter Section Name"> <br>
        <label for="desc">Section Description</label>
        <input type="text" id="desc" name="desc" v-model="section.description" class="form-control" placeholder="Enter Section Description"> <br> <br>
        <div class="col-auto">
            <button @click="updateSection(section.s_id)" class="btn btn-primary">Update</button>
        </div>
    </div>
</template>

<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'UpdateSection',
    components: {
        NavBar
    },
    data() {
      return {
        section: {
            s_id: this.$route.params.id,
            s_name: this.$route.query.section_name,
            description: this.$route.query.description
        }
      };
    },
    methods: {
        async updateSection(s_id) {
            try {
                const response = await fetch(`http://localhost:5000/api/section/${s_id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.section)
                })
                if (response.ok) {
                    console.log('Section updated successfully');
                    this.$router.push({ name: 'section' })
                } else {
                    console.error('Failed to update section');       
                }
            } catch (error) {
                console.error('Error updating section:', error);
            }
        }
    }
}
</script>