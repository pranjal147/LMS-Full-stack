<template>
    <NavBar></NavBar>
    <embed :src="'http://localhost:5000/static/upload/' + book_pdf" height="1000vh" width="100%" type="application/pdf">
</template>

<script>
import NavBar from '@/components/NavBar.vue'

export default {
    name: 'BookPDF',
    components: {
      NavBar
    },
    data () {
        return {
            book_pdf: this.$route.params.pdf
        }
    }
}
</script>