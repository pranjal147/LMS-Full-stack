<template>
    <div>
        <div v-if="message">
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                {{ message }}
                <button @click="close()" type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="container">
            <center>
                <h2>Register an Account</h2> <br>
                <label for="name">Name</label>
                <input type="text" id="name" name="name" v-model="signup.name" class="form-control"> <br>
                <label for="email">Email</label>
                <input type="email" id="email" name="email" v-model="signup.email" class="form-control"> <br>
                <label for="mobile">Mobile</label>
                <input type="number" id="mobile" name="mobile" v-model="signup.mobile" minlength="10" maxlength="10" class="form-control"> <br>
                <label for="password">Password</label>
                <input type="password" id="password" name="password" v-model="signup.password" class="form-control"> <br>
                <label for="re-password">Re-type Password</label>
                <input type="password" id="re-password" name="re-password" placeholder="Retype Password" v-model="signup.re_password" class="form-control"> <br>
                <button class="btn btn-primary" @click="signupUser">Signup</button>
            </center>
        </div>
    </div>
</template>

<script>
export default {
    name: 'SignUp',
    data() {
        return {
            message: null,
            signup: {
                name: null,
                email: null,
                mobile: null,
                password: null,
                re_password: null
            }
        }
    },
    methods: {
        close() {
            this.message = null
        },
        async signupUser() {
            if (this.password===this.re_password) {
                await fetch('http://localhost:5000/register', {
                    method: 'POST',
                    body: JSON.stringify(this.signup),
                    headers: {
                        'Content-type': 'application/json'
                    }
                }).then((res) => {
                    if (res.ok) {
                        this.message = "Registration Successful"
                    } else {
                        this.message = "Somethng went wrong"
                    }
                })
            }
            else {
                message="Type the same password in both fields"
            }
        }
    }
}
</script>

<style scoped>    
    body, html {
        height: 100%;
    }
    .container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100vh;
    }
    form {
        width: 100%;
        max-width: 400px;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        background-color: #f9f9f9;
    }
</style>
