<template>
  <NavBar></NavBar>
  <SectionView></SectionView> <br>
  <BookView></BookView>
</template>


<script>

import NavBar from '@/components/NavBar.vue'
import SectionView from '@/components/SectionView.vue'
import BookView from '@/components/BookView.vue'

export default {
    name: 'Home',
    components: {
      NavBar,
      SectionView,
      BookView,
    },
    data() {
        return {
            message: null,
        }
    },
    methods: {
        close() {
            this.message = null
        }
    }
}
</script>

