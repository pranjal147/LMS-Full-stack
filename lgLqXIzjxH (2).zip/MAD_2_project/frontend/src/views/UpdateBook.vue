<template>
    <NavBar></NavBar>
    <div class="row g-3 align-items-center" style="padding-left:15px;">
      <form @submit.prevent="updateBook(book.b_id)">
        <div class="col-auto">
          <label for="b_name" class="col-form-label">Book Name</label>
          <input type="text" id="b_name" name="b_name" v-model="book.b_name" class="form-control" placeholder="Enter Book Name">
        </div>
        <div class="col-auto">
          <label for="desc" class="col-form-label">Book Description</label>
          <input type="text" id="desc" name="desc" v-model="book.description" class="form-control">
        </div>
        <div class="col-auto">
          <label for="a_name" class="col-form-label">Author Name</label>
          <input type="text" id="a_name" name="a_name" v-model="book.a_name" class="form-control">
        </div>
        <div class="col-auto">
          <label for="select" class="col-form-label">Select Section</label>
          <select name="s_id" id="select" v-model="book.s_id" class="form-control">
            <option v-for="sec in section" :key="sec.s_id" :value="sec.s_id">{{ sec.s_name }}</option>
          </select>
        </div> <br>
        <div class="col-auto">
          <button type="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
</template>

<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'UpdateBook',
    components: {
        NavBar
    },
    data() {
      return {
        book: {
            b_id: this.$route.params.id,
            b_name: this.$route.query.book_name,
            description: this.$route.query.description,
            a_name: this.$route.query.a_name,
            s_id: this.$route.query.s_id
        },
        section: null
      };
    },
    methods: {
        async updateBook(b_id) {
            try {
                const response = await fetch(`http://localhost:5000/api/book/${b_id}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.book)
                })
                if (response.ok) {
                    console.log('Book updated successfully');
                    this.$router.push({ name: 'books' })
                } else {
                    console.error('Failed to update book');       
                }
            } catch (error) {
                console.error('Error updating book:', error);
            }
        }
    },
    async mounted () {
        const response = await fetch('http://localhost:5000/api/sections')
        if (response.ok) {
          const res = await response.json()
          this.section = res
        }
    }
}
</script>