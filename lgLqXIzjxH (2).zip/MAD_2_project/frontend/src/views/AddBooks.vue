<template>
    <NavBar></NavBar>

    <div class="row g-3 align-items-center">
      <form @submit.prevent="submitForm" enctype="multipart/form-data">
        <div class="col-auto">
          <label for="b_name" class="col-form-label">Book Name</label>
          <input type="text" id="b_name" v-model="b_name" class="form-control" placeholder="Enter Book Name">
        </div>
        <div class="col-auto">
          <label for="desc" class="col-form-label">Book Description</label>
          <input type="text" id="desc" v-model="desc" class="form-control">
        </div>
        <div class="col-auto">
          <label for="a_name" class="col-form-label">Author Name</label>
          <input type="text" id="a_name" v-model="a_name" class="form-control">
        </div>
        <div class="col-auto">
          <label for="DOP" class="col-form-label">Date of Publish</label>
          <input type="date" id="DOP" v-model="date_of_publish" class="form-control">
        </div>
        <div class="col-auto">
          <label for="select" class="col-form-label">Select Section</label>
          <select v-model="s_id" id="select" class="form-control">
            <option v-for="sec in sections" :key="sec.s_id" :value="sec.s_id">{{ sec.s_name }}</option>
          </select>
        </div>
        <div class="col-auto">
          <label for="image" class="col-form-label">Upload Image</label>
          <input type="file" id="image" @change="handleImageUpload" class="form-control">
        </div>
        <div class="col-auto">
          <label for="pdf" class="col-form-label">Upload PDF File</label>
          <input type="file" id="pdf" @change="handlePdfUpload" class="form-control">
        </div> <br>
        <div class="col-auto">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
</template>
  
<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'AddBook',
    components: {
        NavBar
    },
    data() {
      return {
        b_name: null,
        desc: null,
        a_name: null,
        date_of_publish: '',
        s_id: null,
        image: null,
        pdf: null,
        sections: null
      };
    },
    methods: {
      handleImageUpload(event) {
        this.image = event.target.files[0];
      },
      handlePdfUpload(event) {
        this.pdf = event.target.files[0];
      },
      async submitForm() {
        const formData = new FormData();
        formData.append('b_name', this.b_name);
        formData.append('desc', this.desc);
        formData.append('a_name', this.a_name);
        formData.append('date_of_publish', this.date_of_publish);
        formData.append('s_id', this.s_id);
        formData.append('image', this.image);
        formData.append('pdf', this.pdf);  
        try {
          const res = await fetch('http://localhost:5000/api/book', {
            method: 'POST',
            body: formData
          });
          if (res.ok) {
            console.log('Book added successfully');
            this.$router.push({ name: 'books' })
          } else {
            console.error('Failed to add a book');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      }
    },
    async mounted () {
        const response = await fetch('http://localhost:5000/api/sections')
        if (response.ok) {
          const res = await response.json()
          this.sections = res
        }
    }
}
</script>
  