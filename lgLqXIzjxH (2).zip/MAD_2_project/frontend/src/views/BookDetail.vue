<template>
    <NavBar></NavBar>
    <div v-if="message">
        <div class="alert alert-warning alert-dismissible fade show" role="alert">
            {{ message }}
            <button @click="close()" type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    </div>
    <div class="container text-center">
      <div class="row align-items-start">
        <div class="col-md-6">
          <img :src="'http://localhost:5000/static/upload/' + book.image" width="500px" height="720px">
        </div>
        <div class="col-md-6">
          <div style="text-align:left;">
            <h4>{{ book.b_name }}</h4>
            <h4>{{ book.a_name }}</h4>
            <h4>{{ book.date_of_publish }}</h4>
            <p>Description - {{ book.description }}</p>
          </div>
        </div>
      </div>
    </div>
    <br>
    <div class="text-center">
      <button class="btn btn-primary" @click="requestBook(book.b_id)">Request a Book</button>
    </div>
</template>


<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'BookDetail',
    components: {
      NavBar
    },
    data() {
      return {
        book: {},
        message: null,
        b_id: this.$route.params.id
      };
    },
    methods: {
      close() {
        this.message = null
      },
      async load_page() {
        const b_id = this.b_id
        const response = await fetch(`http://localhost:5000/api/book/${b_id}`)
        if (response.ok) {
          const res = await response.json()
          this.book = res
        }
      },
      async requestBook(b_id) {
        const token = localStorage.getItem('auth_token')
        console.log(token)
        const response = await fetch(`http://localhost:5000/request/${b_id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        })
        const res = await response.json()
        console.log(res)
        this.message = res
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>
  