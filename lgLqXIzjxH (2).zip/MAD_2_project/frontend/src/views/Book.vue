<template>
    <NavBar></NavBar>
    <div class="container mt-3">
        <h1>Books</h1>
        <table class="table table-striped">
            <thead class="table-primary">
                <tr>
                <th>Book ID</th>
                <th>Name</th>
                <th>Description</th>
                <th>Date of Publish</th>
                <th>Author name</th>
                <th>Section name</th>
                <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr v-for="book in books" :key="book.b_id">
                <td>{{ book.b_id }}</td>
                <td>{{ book.b_name }}</td>
                <td>{{ book.description }}</td>
                <td>{{ book.date_of_publish }}</td>
                <td>{{ book.a_name }}</td>
                <td>{{ book.s_name }}</td>
                <td>
                    <router-link :to="{name: 'update_book', params: {id: book.b_id}, query: {book_name: book.b_name, s_id: book.s_id, description: book.description, a_name:book.a_name, s_name: book.s_name}}" class="btn btn-primary">Update</router-link> &emsp;
                    <button @click="deleteBook(book.b_id)" class="btn btn-danger">Delete</button>
                </td>
                </tr>
            </tbody>
        </table>
        <router-link to="/admin/add_books" class="btn btn-primary">Add Books</router-link>
    </div>
</template>
  
<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'Books',
    components: {
      NavBar
    },
    data() {
      return {
        books: null
      }
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/admin/books')
        if (response.ok) {
          const res = await response.json()
          this.books = res
        }
      },
      async deleteBook(b_id) {
        const conf = confirm("Are you sure want to delete this Book?")
        if (conf) {
          const response = await fetch(`http://localhost:5000/api/book/${b_id}`, {
            method: 'DELETE'
          });
          if (response.ok) {
            this.load_page()
          }
        }
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>