<template>
    
    <NavBar></NavBar>
    <div class="container mt-3">
    <h1>Revoke Access</h1>
    <table class="table table-striped">
        <thead class="table-primary">
        <tr>
            <th>Book Name</th>
            <th>Author</th>
            <th>Date of Issue</th>
            <th>User ID</th>
            <th>Actions</th>
        </tr>
        </thead>
        <tbody>
        <tr v-for="issue in bookIssues" :key="issue.b_issue_id">
            <td scope="row">{{ issue.b_name }}</td>
            <td>{{ issue.a_name }}</td>
            <td>{{ issue.date_of_issue }}</td>
            <td>{{ issue.u_id }}</td>
            <td>
            <a @click="revokeAcesss(issue.b_issue_id)" class="btn btn-danger">Revoke access</a>
            </td>
        </tr>
        </tbody>
    </table>
    </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'RevokeAccess',
    components: {
      NavBar
    },
    data() {
      return {
        bookIssues: null
      }
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/admin/revoke_access')
        if (response.ok) {
          const res = await response.json()
          this.bookIssues = res
        }
      },
      async revokeAcesss(b_issue_id) {
        const revreq = await fetch(`http://localhost:5000/admin/revoke_access/${b_issue_id}`)
        if (revreq.ok) {
            const rev = await revreq.json()
            this.load_page()
        }
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>
  