<template>
    <NavBar></NavBar>
    <div class="container mt-3">
      <h1>Book Requests</h1>
      <table class="table table-striped">
        <thead class="table-primary">
          <tr>
            <th>Book Name</th>
            <th>Date of Publish</th>
            <th>Author</th>
            <th>User Name</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="req in bookRequests" :key="req.r_id">
            <td scope="row">{{ req.b_name }}</td>
            <td>{{ req.date_of_publish }}</td>
            <td>{{ req.a_name }}</td>
            <td>{{ req.username }}</td>
            <td>
              <a v-if="!req.status" @click="acceptRequest(req.r_id, req.u_id)" class="btn btn-success">Accept</a> &emsp;
              <a v-if="!req.status" @click="deleteRequest(req.r_id)" class="btn btn-danger">Reject</a>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'Request',
    components: {
      NavBar
    },
    data() {
      return {
        bookRequests: null
      }
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/admin/requests')
        if (response.ok) {
          const res = await response.json()
          this.bookRequests = res
        }
      },
      async deleteRequest(r_id) {
        const delreq = await fetch(`http://localhost:5000/admin/reject_request/${r_id}`)
        if (delreq.ok) {
            const del = await delreq.json()
            this.load_page()
        }
      },
      async acceptRequest(r_id, u_id) {
        const accreq = await fetch(`http://localhost:5000/admin/accept_request/${r_id}/${u_id}`)
        if (accreq.ok) {
            const acc = await accreq.json()
            this.load_page()
        }
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>