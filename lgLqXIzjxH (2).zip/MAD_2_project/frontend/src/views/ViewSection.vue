<template>
    <NavBar></NavBar>
    <SectionView></SectionView>
</template>

<script>

import NavBar from '@/components/NavBar.vue'
import SectionView from '@/components/SectionView.vue'


export default {
    name: 'ViewSection',
    components: {
        NavBar,
        SectionView
    }
}
</script>