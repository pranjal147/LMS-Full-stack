<template>
    <div>
        <div v-if="message">
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                {{ message }}
                <button @click="close()" type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
        <div class="login_page">
            <div id=login_form>
                <center><h2>Login</h2></center> <br>
                <div class="mb-3">
                    <center><label for="email" class="form-label">Email</label></center>
                    <input type="email" class="form-control" v-model="login_cred.email"  id="email" style="width: 100%;" name="email">
                </div>
                <div class="mb-3">
                    <center><label for="password" class="form-label">Password</label></center>
                    <input type="password" class="form-control" v-model="login_cred.password" id="password" name="password">
                </div>
                <button @click="login" class="btn btn-primary btn-login" style="width: 100%">Login</button> <br> <br>
                <center><RouterLink to="/register"><button class="btn btn-secondary">SignUp</button></RouterLink></center>
            </div>
        </div>
        
    </div>
</template>

<script>
export default {
    name: 'Login',
    data() {
        return {
            message: null,
            login_cred: {           
                email: null,
                password: null,
            }
        }
    },
    methods: {
        close() {
            this.message = null
        },
        async login() {
            await fetch('http://localhost:5000/login', {
                method: 'POST',
                body: JSON.stringify(this.login_cred),
                headers: {
                    'Content-type': 'application/json'
                }
            }).then(async (res) => {
                if (res.ok) {
                    const token = await res.json()
                    console.log(token['access_token']);
                    localStorage.setItem('auth_token', token['access_token']);
                    this.$router.push({name: 'home'})
                } else {
                    this.message = "Enter the right credentials to login"
                }
            })
        }
    }
}
</script>

<style scoped>    
.login_page {
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
        background-color: #f8f9fa;
}
#login_form {
        max-width: 400px;
        padding: 70px;
        background-color: #fff;
        border-radius: 5px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
</style>