<template>
    <NavBar></NavBar>
    <div class="container mt-3">
      <h1>Sections</h1>
      <table class="table table-striped">
        <thead class="table-primary">
          <tr>
            <th>Section ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="sec in sections" :key="sec.s_id">
            <td>{{ sec.s_id }}</td>
            <td>{{ sec.s_name }}</td>
            <td>{{ sec.description }}</td>
            <td>
              <router-link :to="{name: 'update_section', params: {id: sec.s_id}, query: {section_name: sec.s_name, description: sec.description}}" class="btn btn-primary">Update</router-link> &emsp;
              <button role="button" @click="delete_section(sec.s_id)" class="btn btn-danger">Delete</button>
            </td>
          </tr>
        </tbody>
      </table>
      <router-link to="/admin/add_section" class="btn btn-primary">Add Section</router-link>
    </div>
</template>
  
<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'Sections',
    components: {
      NavBar
    },
    data() {
      return {
        sections: null
      };
    },
    methods: {
      async load_page() {
        const response = await fetch('http://localhost:5000/api/sections')
        if (response.ok) {
          const res = await response.json()
          this.sections = res
        }
      },
      async delete_section(s_id) {
        const conf = confirm("Are you sure want to delete this section?")
        if (conf) {
          const response = await fetch(`http://localhost:5000/api/section/${s_id}`, {
            method: 'DELETE'
          });
          if (response.ok) {
            this.load_page()
          }
        }
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>
  