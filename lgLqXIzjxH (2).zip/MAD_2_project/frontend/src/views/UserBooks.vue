<template>
    <div>
      <NavBar></NavBar>
      <div class="container text-center">
        <div class="row align-items-center">
          <div class="col-md-9">
            <h2>My Books</h2>
            <table class="table table-striped">
              <thead class="table-primary">
                <tr>
                  <th>Book ID</th>
                  <th>Name</th>
                  <th>Description</th>
                  <th>Author</th>
                  <th></th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="bookIssue in bookIssues" :key="bookIssue.b_id">
                  <td scope="row">{{ bookIssue.b_id }}</td>
                  <td><router-link :to="{ name: 'readbook', params: { pdf: bookIssue.pdf }}">
  {{ bookIssue.b_name }}
</router-link></td>
                  <td>{{ bookIssue.description }}</td>
                  <td>{{ bookIssue.a_name }}</td>
                  <td><a class="btn btn-primary" @click="returnBook(bookIssue.b_issue_id, bookIssue.b_id)">Return</a></td>
                  <td><router-link :to="{ name: 'feedback', params: { id: bookIssue.b_id } }" class="btn btn-info">Feedback</router-link></td>
                </tr>
              </tbody>
            </table>
          </div>
          <div class="col-md-3">
            <h2>Requests</h2>
            <table class="table table-striped">
              <thead class="table-primary">
                <tr>
                  <th>Req ID</th>
                  <th>Book</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="req in requests" :key="req.r_id">
                  <td scope="row">{{ req.req_id }}</td>
                  <td>{{ req.b_name }}</td>
                  <td>{{ req.status }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
</template>


<script>
import NavBar from '@/components/NavBar.vue'
  
export default {
    name: 'UserBooks',
    components: {
      NavBar
    },
    data() {
      return {
        bookIssues: null,
        requests: null
      };
    },
    methods: {
      async load_page() {
        const token = localStorage.getItem('auth_token')
        const book_issues = await fetch('http://localhost:5000/my_books', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        })
        const bi = await book_issues.json()
        this.bookIssues = bi

        const requests = await fetch('http://localhost:5000/user_requests', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        })
        const req = await requests.json()
        this.requests = req
      },
      async returnBook(b_issue_id, b_id) {
        const token = localStorage.getItem('auth_token')
        const returnbook = await fetch(`http://localhost:5000/return_book/${b_issue_id}/${b_id}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            }
        })
        const retn = await returnbook.json()
        console.log(retn)
        this.load_page()
      }
    },
    async mounted() {
      this.load_page()
    }
}
</script>
  