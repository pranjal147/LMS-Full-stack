<template>
    <div>
      <NavBar />
      <h1>Search results for {{ query.q }}</h1>
      <br>
      <div v-if="Object.keys(sections).length > 0">
        <div class="container mt-3">
            <h3>Sections</h3> <br>
            <div class="grid">
                <div v-for="sec in sections" :key="sec.s_id">
                <router-link :to="{name: 'section_books', params: {id: sec.s_id}}" id="link">
                <div class="card" style="width:300px; height:450px">
                    <img :src="'http://localhost:5000/static/upload/' + sec.image" class="card-img-top" alt="..." height="300px">
                    <div class="card-body">
                    <h2>{{ sec.s_name }}</h2>
                    <p class="card-text text-truncate">{{ sec.description }}</p>
                    </div>
                </div>
                </router-link>
                </div>
            </div>
        </div>
      </div>
      <br>
      <div v-if="Object.keys(books).length > 0">
        <div class="container mt-3">
            <h3>Books</h3> <br>
            <div class="grid">
            <div v-for="book in books" :key="book.b_id">
            <router-link :to="{name: 'book_detail', params: {id: book.b_id}}" id="link">
                <div class="card" style="width:300px; height:500px;">
                <img :src="'http://localhost:5000/static/upload/' + book.image" class="card-img-top" alt="..." height="300px">
                <div class="card-body">
                    <h2>{{ book.b_name }}</h2>
                    <p class="card-text text-truncate">{{ book.description }}</p>
                    <p class="card-text">{{ book.a_name }}</p>
                </div>
                </div>
            </router-link>
            </div>
            </div>
        </div>
      </div>
    </div>
</template>


<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'SearchResults',
    data() {
      return {
        query: { q: this.$route.query.q },
        books: {},
        sections: {}
      }
    },
    components: {
        NavBar
    },
    async mounted() {
        const queryparams = new URLSearchParams(this.query)
        const search_data = await fetch('http://localhost:5000/search?'+queryparams)
        const res = await search_data.json()
        console.log(res)
        this.books = res.books
        this.sections = res.sections
    }
}
</script>


<style scoped>
    .grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    #link {
        text-decoration: none;
    }
</style>