<template>
    <NavBar></NavBar>
    <BookView></BookView>
</template>

<script>

import NavBar from '@/components/NavBar.vue'
import BookView from '@/components/BookView.vue'


export default {
    name: 'ViewBook',
    components: {
        NavBar,
        BookView
    }
}
</script>