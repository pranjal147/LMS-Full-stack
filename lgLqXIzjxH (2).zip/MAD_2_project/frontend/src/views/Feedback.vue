<template>
    <NavBar></NavBar>
    <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <div class="card">
          <div class="card-header">Feedback Form</div>
          <div class="card-body">
              <div class="form-group">
                <label for="ratings">Ratings</label>
                <div>
                  <input v-model="review.rating" id="ratings1" type="radio" value="1" name="ratings">
                  <label for="ratings1">1</label> &emsp;
                  <input v-model="review.rating" id="ratings2" type="radio" value="2" name="ratings">
                  <label for="ratings2">2</label> &emsp;
                  <input v-model="review.rating" id="ratings3" type="radio" value="3" name="ratings">
                  <label for="ratings3">3</label> &emsp;
                  <input v-model="review.rating" id="ratings4" type="radio" value="4" name="ratings" checked>
                  <label for="ratings4">4</label> &emsp;
                  <input v-model="review.rating" id="ratings5" type="radio" value="5" name="ratings">
                  <label for="ratings5">5</label>
                </div>
              </div> <br>
              <div class="form-group">
                <label for="feedback">Feedback</label>
                <textarea v-model="review.feedback" class="form-control" name="feedback" rows="5"></textarea>
              </div> <br>
              <button @click="submitFeedback(book_id)" class="btn btn-primary">Submit Feedback</button>
          </div>
        </div>
      </div>
    </div>
    </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'

export default {
    name: 'Feedback',
    components: {
      NavBar
    },
    data () {
        return {
            review: {
                rating: "4",
                feedback: null
            },
            book_id: this.$route.params.id
        }
    },
    methods: {
        async submitFeedback(b_id) {
        console.log("Feedback")
        const token = localStorage.getItem('auth_token')
        const feedback = await fetch(`http://localhost:5000/feedback/${b_id}`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify(this.review)
        })
        if (feedback.ok) {
            const bi = await feedback.json()
            this.bookIssues = bi
            this.$router.push({name: 'my_books'})
        }
    }
    }
}
</script>