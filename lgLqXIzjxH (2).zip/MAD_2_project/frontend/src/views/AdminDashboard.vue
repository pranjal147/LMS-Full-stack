<template>
    <NavBar></NavBar>
    <div class="container text-center">
        <div class="row align-items-center">
          <div class="col-md-3">
            <a class="btn btn-primary" href='/admin/sections'>Sections</a>
          </div>
          <div class="col-md-3">
            <a class="btn btn-primary" href='/admin/books'>Books</a>
          </div>
          <div class="col-md-3">
            <a class="btn btn-primary" href='/admin/requests'>Request from Users</a>
          </div>
          <div class="col-md-3">
            <a class="btn btn-primary" href="/admin/revoke_access">Revoke access</a>
          </div>
        </div>
    </div>

    <br>

    <h2>Statistics</h2> <br>

    <div class="container-md text-center">
      <div class="row">
        <div class="col-md-6">
          <img src="http://localhost:5000/static/pie_chart.png" width="500px">
        </div>
        <div class="col-md-6">
          <img src="http://localhost:5000/static/books_bar_chart.png" height="500px" width="650px">
        </div>
      </div>
    </div>
</template>

<script>
import NavBar from '@/components/NavBar.vue'

export default {
    name: 'AdminDashboard',
    components: {
        NavBar
    },
    data() {
        return {
            message: null,
        }
    },
    methods: {
        close() {
            this.message = null
        }
    },
    async mounted() {
      const chart = await fetch('http://localhost:5000/admin')
      const res = await chart.json()
      console.log(res)
    }
}
</script>