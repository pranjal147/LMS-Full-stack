<template>
    <NavBar></NavBar>
    <div class="container mt-3">
      <h3>Books</h3>
      <div class="grid">
        <div v-for="book in books" :key="book.b_id">
        <router-link :to="{name: 'book_detail', params: {id: book.b_id}}" id="link">
          <div class="card" style="width:300px; height:500px;">
            <img :src="'http://localhost:5000/static/upload/' + book.image" class="card-img-top" alt="..." height="300px">
            <div class="card-body">
              <h2>{{ book.b_name }}</h2>
              <p class="card-text text-truncate">{{ book.description }}</p>
              <p class="card-text">{{ book.a_name }}</p>
            </div>
          </div>
        </router-link>
        </div>
      </div>
    </div>
</template>

<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'SectionBook',
    components: {
        NavBar
    },
    data() {
      return {
        books: null,
        s_id: this.$route.params.id,
      }
    },
    methods: {
      async load_page() {
        const s_id = this.s_id
        const response = await fetch(`http://localhost:5000/api/section_books/${s_id}`)
        if (response.ok) {
          const res = await response.json()
          this.books = res
        }
      }
    },
    async mounted() {
        this.load_page()
    }
}
</script>


<style scoped>
    .grid {
        display: grid;
        gap: 1rem;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    #link {
        text-decoration: none;
    }
</style>