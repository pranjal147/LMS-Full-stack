<template>
    <NavBar></NavBar>
    <div class="row g-3 align-items-center" style="padding-left:15px;">
      <form @submit.prevent="submitForm" enctype="multipart/form-data">
        <div class="col-auto">
          <label for="s_name" class="col-form-label">Section Name</label>
          <input v-model="s_name" type="text" id="s_name" name="s_name" class="form-control" placeholder="Enter Section Name">
        </div> <br>
        <div class="col-auto">
          <label for="desc" class="col-form-label">Section Description</label>
          <input v-model="desc" type="text" id="desc" name="desc" class="form-control" placeholder="Enter Section Description">
        </div> <br>
        <div class="col-auto">
          <label for="image" class="col-form-label">Upload Image</label>
          <input type="file" id="image" name="image" class="form-control" @change="handleImageChange">
        </div> <br>
        <div class="col-auto">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
</template>
  
<script>

import NavBar from '@/components/NavBar.vue'

export default {
    name: 'AddSection',
    components: {
        NavBar
    },
    data() {
      return {
        s_name: '',
        desc: '',
        image: null
      };
    },
    methods: {
      handleImageChange(event) {
        this.image = event.target.files[0];
      },
      async submitForm() {
        const formData = new FormData();
        formData.append('s_name', this.s_name);
        formData.append('desc', this.desc);
        formData.append('image', this.image);
  
        try {
          const res = await fetch('http://localhost:5000/api/section', {
            method: 'POST',
            body: formData
          });
          if (res.ok) {
            console.log('Section added successfully');
            this.$router.push({ name: 'section' })
          } else {
            console.error('Failed to add section');
          }
        } catch (error) {
          console.error('Error:', error);
        }
      }
    }
}
</script>