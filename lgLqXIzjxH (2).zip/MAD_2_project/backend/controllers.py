from flask import current_app as app
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required, JWTManager, get_jwt, decode_token, get_current_user, current_user
from app import jwt, cache
from flask import request, jsonify
from models import  *
from datetime import datetime, date, timedelta
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import seaborn as sns



@app.route('/')
def home():
    return {
        'user': 'Pranjal',
        'password': 1234
    }

@app.route('/info')
@jwt_required()
def info():
    current_user = get_jwt_identity()
    claims = get_jwt()
    print (current_user)
    print(claims)
    return jsonify(logged_in_as=current_user), 200


# # Loading the user state

@jwt.user_identity_loader
def user_identity_lookup(user):
    return user.id

@jwt.user_lookup_loader
def user_lookup_callback(_jwt_header, jwt_data):
    identity = jwt_data["sub"]
    return User.query.filter_by(id=identity).one_or_none()

@app.route("/identity", methods=["GET"])
@jwt_required()
@cache.cached(key_prefix='identity', timeout=120)
def protected():
    return jsonify(
        id=current_user.id,
        name=current_user.name,
        email=current_user.email,
        role=current_user.role
    )

@app.route('/register', methods=['POST'])
def signup():
    result = request.json
    name = result.get('name')
    password = result.get('password')
    # hash the password and store it database
    hashed_password = generate_password_hash(password, method='scrypt')
    re_password = result.get('re_password')
    email = result.get('email')
    mobile = result.get('mobile')

    # check for user already exist
    user = User.query.filter((User.email == email) | (User.mobile_no == mobile) ).all()
    if user:
        message = "Account already exist. Do Login "
        return  jsonify(message), 409
    else:
        if password==re_password:
                u1 = User(name = name, password=hashed_password, email=email, mobile_no=mobile)
                db.session.add(u1)
                db.session.commit()

                msg = "Your account has been successfully created"
                return jsonify(msg), 200 
        else:
            msg = "Type the same password in fields both password and retype-password"
            return jsonify(msg), 403


@app.route('/login', methods=['POST'])
def login():
    result=request.json
    email=result.get('email')
    password=str(result.get('password'))
    user = User.query.filter_by(email=email).first()
    if user and check_password_hash(user.password, password):        
        access_token = create_access_token(user, additional_claims={'role': user.role})
        user.last_logged_in = datetime.now()
        db.session.commit()
        return jsonify(access_token=access_token), 200
    else:
        msg="Enter the right credential to login"    
        return jsonify(msg), 401


@app.route('/logout')
def logout():
    msg="Logged out"
    cache.delete('identity')
    return jsonify(msg), 200

@app.route('/admin/books')
@cache.cached(key_prefix='admin_books')
def books():
    books= Books.query.all()
    data = []
    for book in books:
        D = {}
        D['b_id'] = book.b_id
        D['b_name'] = book.b_name
        D['description'] = book.description
        D['a_name'] = book.a_name
        D['date_of_publish'] = book.date_of_publish
        D['s_id'] = book.s_id
        D['s_name'] = book.section.s_name
        D['image'] = book.image
        D['pdf'] = book.pdf
        data.append(D)
    return jsonify(data), 200


@app.route('/request/<int:b_id>')
@jwt_required()
def user_request(b_id):
    current_user = get_jwt_identity()
    request = Request.query.filter(Request.status==False, Request.u_id==current_user).count()
    if request>=5:
        msg="You have already exceeded your number of requests"
        return jsonify(msg), 200
    else:
        r = Request.query.filter_by(u_id=current_user, b_id=b_id, status=False).all()
        b_i = BookIssues.query.filter_by(u_id=current_user, b_id=b_id, access=True).all()
        if r or b_i:
            msg="Book has been already issued or request is in Pending"
            return jsonify(msg), 200
        else:
            r1 = Request(b_id=b_id, u_id=current_user, status=False)
            db.session.add(r1)
            db.session.commit()
            msg="Request has been successfully accepted"
            return jsonify(msg), 200


@app.route('/my_books')
@jwt_required()
def my_books():
    current_user = get_jwt_identity()
    books = BookIssues.query.filter_by(u_id=current_user, access=True).all()
    for bi in books:
        doi = bi.date_of_issue
        exp_ret_date = doi + timedelta(days=7)
        if exp_ret_date < datetime.now():
            b_issue = BookIssues.query.get(bi.b_issue_id)
            b_issue.access = False
            db.session.add(b_issue)
            db.session.commit()
    books = BookIssues.query.filter_by(u_id=current_user, access=True).all()
    
    book_issues = []
    for b_i in books:
        D = {}
        D['b_id'] = b_i.b_id
        D['b_issue_id'] = b_i.b_issue_id
        D['b_name'] = b_i.book.b_name
        D['description'] = b_i.book.description
        D['a_name'] = b_i.book.a_name
        D['pdf'] = b_i.book.pdf
        book_issues.append(D)
    return jsonify(book_issues), 200


@app.route('/user_requests')
@jwt_required()
def my_requests():
    current_user = get_jwt_identity()
    request = Request.query.filter_by(u_id=current_user, status=False).all()
    requests = []
    for r in request:
        D = {}
        D['req_id'] = r.r_id
        D['status'] = r.status
        D['b_name'] = r.book.b_name
        requests.append(D)
        
    return jsonify(requests), 200



@app.route('/search')
def search():
    q_string = request.args.get('q')
    q_name = '%{}%'.format(q_string)
    
    search_dict = {"sections": [], "books": []}
    books = Books.query.filter( (Books.b_name.like(q_name)) | 
                                   (Books.a_name.like(q_name)) | (Books.description.like(q_name)) | 
                                   (Books.date_of_publish.like(q_name)) ).all()
    
    sections = Section.query.filter(Section.s_name.like(q_name) | Section.description.like(q_name) ).all()
    
    for book in books:
        D={}
        D['b_id'] = book.b_id
        D['b_name'] = book.b_name
        D['a_name'] = book.a_name
        D['image'] = book.image
        D['description'] = book.description
        search_dict['books'].append(D)
    
    for sec in sections:
        D={}
        D['s_id'] = sec.s_id
        D['s_name'] = sec.s_name
        D['image'] = sec.image
        D['description'] = sec.description
        search_dict['sections'].append(D)
    
    return jsonify(search_dict), 200


@app.route('/admin/requests')
def requests():
    request = Request.query.all()
    requests=[]
    for req in request:
        D = {}
        D['r_id'] = req.r_id
        D['u_id'] = req.u_id
        D['status'] = req.status
        D['b_name'] = req.book.b_name
        D['a_name'] = req.book.a_name
        D['username'] = req.user.name
        D['date_of_publish'] = req.book.date_of_publish
        requests.append(D)
    return jsonify(requests), 200

@app.route('/admin/reject_request/<int:r_id>')
def reject_request(r_id):
    r = Request.query.get(r_id)
    db.session.delete(r)
    db.session.commit()
    msg="Request has been rejected"
    return jsonify(msg), 200


@app.route('/admin/accept_request/<int:r_id>/<int:u_id>')
def accept_request(r_id, u_id):
    r = Request.query.get(r_id)
    book_issue = BookIssues(u_id=u_id, b_id=r.b_id)
    db.session.add(book_issue)
    db.session.commit()
    db.session.delete(r)
    db.session.commit()
    msg="Book has been issued successfully"
    return jsonify(msg), 200

@app.route('/admin/revoke_access')
def revoke_access():
    b_issues=BookIssues.query.filter_by(access=True).all()
    book_issues = []
    for issue in b_issues:
        D = {}
        D['b_issue_id'] = issue.b_issue_id
        D['b_name'] = issue.book.b_name
        D['a_name'] = issue.book.a_name
        D['date_of_issue'] = issue.date_of_issue
        D['u_id'] = issue.u_id
        D['username'] = issue.user.name
        book_issues.append(D)
    return jsonify(book_issues), 200

@app.route('/admin/revoke_access/<int:b_issue_id>')
def revoke_book_access(b_issue_id):
    b_issue = BookIssues.query.get(b_issue_id)
    b_issue.access = False
    db.session.add(b_issue)
    db.session.commit()
    return jsonify("Access has been revoked"), 200

@app.route('/feedback/<int:b_id>', methods=['POST'])
@jwt_required()
def feedback(b_id):
    current_user = get_jwt_identity()
    result=request.json
    rating=result.get('rating')
    feedback=result.get('feedback')
    r1 = Review(rating=rating, feedback=feedback, b_id=b_id, u_id=current_user)
    db.session.add(r1)
    db.session.commit()
    return jsonify("Feedback accepted"), 200


@app.route('/return_book/<int:b_issue_id>/<int:b_id>')
@jwt_required()
def return_book(b_issue_id, b_id):
    current_user = get_jwt_identity()
    b_issue=BookIssues.query.get(b_issue_id)
    b_issue.access = False
    db.session.add(b_issue)
    db.session.commit()
    rtn = Return(u_id=current_user, b_id=b_id, b_issue_id=b_issue_id)
    db.session.add(rtn)
    db.session.commit()
    return jsonify("Book has been returned"), 200


@app.route('/admin')
def admin_home():
    b_issues = BookIssues.query.all()
    sections, books = [], []
    for bi in b_issues:
        sections.append(bi.book.section.s_name)
        books.append(bi.book.b_name)
    print(sections)
    print(books)
    genre_counts = {genre: sections.count(genre) for genre in set(sections)}

    # Plotting a pie chart
    plt.figure(figsize=(8, 8))
    plt.pie(genre_counts.values(), labels=genre_counts.keys(), autopct='%1.1f%%')
    plt.title('Book Genres')
    plt.tight_layout()
    plt.savefig('static/pie_chart.png')
    plt.show()
    
    
    # Plotting a bar chart
    plt.figure(figsize=(8, 6))
    sns.countplot(x=books)
    plt.title('Number of Books by Genre')
    plt.xlabel('Books')
    plt.ylabel('Count')
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.savefig('static/books_bar_chart.png')
    plt.show()
    return "Chart Plotted", 200