from flask import current_app as app
from flask import request, jsonify

# -------------- Celery Task --------------- #

from celery.result import AsyncResult
from tasks import send_daily_remainder, send_monthly_report
from celery.schedules import crontab
from app import cel_app

@cel_app.on_after_configure.connect
def setup_daily_task(sender, **kwargs):
    sender.add_periodic_task(
        crontab(hour=17, minute=0),
        send_daily_remainder.s()
    )
    
@cel_app.on_after_configure.connect
def setup_monthly_task(sender, **kwargs):
    sender.add_periodic_task(
        crontab(day_of_month=1), 
        #crontab(minute='*'),
        send_monthly_report.s()
    )