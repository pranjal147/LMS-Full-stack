from celery import Celery, Task
import celeryconfiq as celeryconfiq

def create_celery_app(app):
    class FlaskTask(Task):
        def __call__(self, *args, **kwargs):
            with app.app_context():
                return self.run(*args, **kwargs)

    cel = Celery(app.name, task_cls=FlaskTask)
    cel.config_from_object(celeryconfiq)  
    cel.set_default()
    return cel  

### Command to start celery

## celery -A app.cel_app worker -l INFO
## celery -A app.cel_app beat -l INFO

# To run mailhog
# ~/go/bin/MailHog

# pip install -r requirements.txt

# sudo apt update
# sudo apt install redis-server

# redis-cli ping (check if redis is already running)
# redis-server (to start the server)
# redis-cli shutdown (shutdown redis)

## To delete the cache of a function
# cache.delete_memoized(func_name, 'for which args you want to delete')

## clear all the 
# cache.clear()