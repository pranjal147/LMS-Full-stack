from flask_sqlalchemy import SQLAlchemy
from datetime import datetime


db=SQLAlchemy()


#_________________________Models__________________________________


    

class User(db.Model):
    __tablename__='user'
    id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    name=db.Column(db.String(50), nullable=False)
    email=db.Column(db.String(), nullable=False, unique=True)
    password=db.Column(db.String(), nullable=False)
    mobile_no= db.Column(db.Integer(), nullable=False)
    role = db.Column(db.String(5), nullable=False, default='user')
    last_logged_in = db.Column(db.DateTime())
    bookissues=db.relationship('BookIssues', backref='user')
    requests=db.relationship('Request', backref='user')
    returns=db.relationship('Return', backref='user')
    

    
class Section(db.Model):
    __tablename__='section'
    s_id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    s_name=db.Column(db.String(), nullable=False)
    description=db.Column(db.String())
    date_of_creation=db.Column(db.DateTime(), default=datetime.now())
    image = db.Column(db.String())
    books=db.relationship('Books',backref='section', cascade="all, delete", lazy=True)
    
    
class Books(db.Model):
    __tablename__='books'
    b_id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    b_name=db.Column(db.String(), nullable=False)
    description=db.Column(db.String())
    date_of_publish=db.Column(db.DateTime(), nullable=False)
    a_name=db.Column(db.String(), nullable=False)
    s_id=db.Column(db.Integer(), db.ForeignKey('section.s_id'), nullable=False)
    image = db.Column(db.String())
    pdf = db.Column(db.String())
    reviews=db.relationship('Review', backref='book')
    requests=db.relationship('Request', backref='book')
    returns=db.relationship('Return', backref='book')
    book_issues=db.relationship('BookIssues', backref='book')
    
    
class Request(db.Model):
    __tablename__='request'
    r_id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    b_id=db.Column(db.Integer(), db.ForeignKey('books.b_id'), nullable=False)
    u_id=db.Column(db.Integer(), db.ForeignKey('user.id'), nullable=False)
    status=db.Column(db.Boolean(), default=False, nullable=False)
    

class Return(db.Model):
    __tablename__='return'
    ret_id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    u_id=db.Column(db.Integer(), db.ForeignKey('user.id'), nullable=False)
    b_id=db.Column(db.Integer(), db.ForeignKey('books.b_id'), nullable=False)
    date_of_return=db.Column(db.DateTime(), nullable=False, default=datetime.now())
    b_issue_id=db.Column(db.Integer(), db.ForeignKey('bookissues.b_issue_id'), nullable=False)
    b_issue= db.relationship('BookIssues', backref='return_b', uselist=False) # One to one
    
    
class BookIssues(db.Model):
    __tablename__='bookissues'
    b_issue_id=db.Column(db.Integer(), primary_key=True, autoincrement=True)
    u_id=db.Column(db.Integer(), db.ForeignKey('user.id'), nullable=False)
    b_id=db.Column(db.Integer(), db.ForeignKey('books.b_id'), nullable=False)
    access = db.Column(db.Boolean(), default=True)
    date_of_issue=db.Column(db.DateTime(), default=datetime.now(), nullable=False)   
    

class Review(db.Model):
    __tablename__='review'
    rev_id=db.Column(db.Integer(), primary_key=True)
    u_id=db.Column(db.Integer(), db.ForeignKey('user.id'), nullable=False)
    b_id=db.Column(db.Integer(), db.ForeignKey('books.b_id'), nullable=False)
    rating=db.Column(db.Integer(),nullable=False)
    feedback=db.Column(db.String())
    
    


    