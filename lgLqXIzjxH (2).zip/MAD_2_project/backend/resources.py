from flask_restful import Resource, reqparse, fields, marshal_with
from flask import request
from models import *
from validation import *
import os
from werkzeug.utils import secure_filename
from flask import current_app as app
from app import cache

# ----Output field----

section_field = {
    's_id': fields.Integer,
    's_name': fields.String,
    'description': fields.String,
    'image': fields.String
}

book_field = {
    'b_id': fields.Integer,
    'b_name': fields.String,
    'a_name': fields.String,
    'date_of_publish': fields.String,
    'description': fields.String,
    'image': fields.String,
    'pdf': fields.String,
}

# ------Parser-----

section_parser = reqparse.RequestParser()
section_parser.add_argument('s_id')
section_parser.add_argument('s_name')
section_parser.add_argument('description')

books_parser = reqparse.RequestParser()
books_parser.add_argument('b_id')
books_parser.add_argument('b_name')
books_parser.add_argument('a_name')
books_parser.add_argument('description')
books_parser.add_argument('s_id')

# ----------- API(s) -------------

class SectionAPI(Resource):
    @marshal_with(section_field)
    @cache.memoize()
    def get(self, s_id):
        s = Section.query.get(s_id)
        if s:
            return s, 200
        else:
            raise Not_Found_Error(status_code=404, error_code="SEC_404", error_message="Section not found")
    
    @marshal_with(section_field)
    def post(self):
        img_file = request.files.get('image')
        s_name=request.form.get('s_name')
        description=request.form.get('desc')
        
        s1 = Section(s_name=s_name, description=description) 
        db.session.add(s1)
        if img_file:
            image = secure_filename(img_file.filename) # type: ignore
            img_file.save(os.path.join(app.config['UPLOAD_FOLDER'], image))
            s1.image = image
        cache.delete('sections')
        db.session.commit()
        return s1, 200
    
    @marshal_with(section_field)
    def put(self, s_id):
        sec = section_parser.parse_args()
        s1 = Section.query.get(s_id)
        if s1:
            s1.s_name=sec['s_name']
            s1.description=sec['description'] 
            db.session.add(s1)
            db.session.commit()
            cache.delete('sections')
            return s1, 202
        else:
            raise Not_Found_Error(status_code=404, error_code="SEC_404", error_message="Section not found")
    
    
    @marshal_with(section_field)
    def delete(self, s_id):
        s1 = Section.query.get(s_id)
        if s1: 
            db.session.delete(s1)
            db.session.commit()
            cache.delete('sections')
            return s1, 200
        else:
            raise Not_Found_Error(status_code=404, error_code="SEC_404", error_message="Section not found")
        


class BookAPI(Resource):
    @marshal_with(book_field)
    @cache.memoize()
    def get(self, b_id):
        s = Books.query.get(b_id)
        if s:
            return s, 200
        else:
            raise Not_Found_Error(status_code=404, error_code="BOOK_404", error_message="Book not found")
    
    @marshal_with(book_field)
    def post(self):
        img_file = request.files.get('image')
        pdf_file = request.files.get('pdf')
        b_name=request.form.get('b_name')
        description=request.form.get('desc')
        a_name=request.form.get('a_name')
        date_of_publish=request.form.get('date_of_publish')
        s_id=request.form.get('s_id')

        date_of_publish = datetime.strptime(date_of_publish, '%Y-%m-%d')
        b1 = Books(b_name=b_name, description=description, a_name=a_name, date_of_publish=date_of_publish, s_id=s_id) 
        db.session.add(b1)
        if img_file and pdf_file:
            image = secure_filename(img_file.filename)
            pdf = secure_filename(pdf_file.filename)
            img_file.save(os.path.join(app.config['UPLOAD_FOLDER'], image))
            pdf_file.save(os.path.join(app.config['UPLOAD_FOLDER'], pdf))
            b1.image = image
            b1.pdf = pdf
        cache.delete('books')
        cache.delete('admin_books')
        db.session.commit()
        return b1, 200
    
    @marshal_with(book_field)
    def put(self, b_id):
        book = books_parser.parse_args()
        print(book)
        b1 = Books.query.get(b_id)
        if b1:
            b1.b_name=book['b_name']
            b1.description=book['description']
            b1.a_name=book['a_name']
            # b1.date_of_publish = datetime.strptime(book['date_of_publish'], '%Y-%m-%d')
            b1.s_id=book['s_id']
            db.session.add(b1)
            db.session.commit()
            cache.delete('books')
            cache.delete('admin_books')
            return b1, 202
        else:
            raise Not_Found_Error(status_code=404, error_code="BOOK_404", error_message="Book not found")
    
    
    @marshal_with(book_field)
    def delete(self, b_id):
        b1 = Books.query.get(b_id)
        if b1: 
            db.session.delete(b1)
            db.session.commit()
            cache.delete('books')
            cache.delete('admin_books')
            return b1, 200
        else:
            raise Not_Found_Error(status_code=404, error_code="BOOK_404", error_message="Book not found")
        
class AllSections(Resource):
    @marshal_with(section_field)
    @cache.cached(key_prefix='sections')
    def get(self):
        sections = Section.query.all()
        return sections, 200

class AllBooks(Resource):
    @marshal_with(book_field)
    @cache.cached(key_prefix='books')
    def get(self):
        books = Books.query.all()
        return books, 200
    
class All_Section_Books(Resource):
    @marshal_with(book_field)
    @cache.memoize()
    def get(self, s_id):
        books = Books.query.filter_by(s_id=s_id).all()
        return books, 200
