from flask import make_response
from werkzeug.exceptions import HTTPException
import json

class Not_Found_Error(HTTPException):
    def __init__(self, error_message, status_code, error_code):
        message = {"error_code": error_code, "error_message": error_message}
        self.response = make_response(json.dumps(message), status_code)