from flask import Flask, request, redirect, flash, jsonify
from flask import render_template
from flask_jwt_extended import create_access_token, get_jwt_identity, jwt_required, JWTManager, get_jwt, decode_token, get_current_user, current_user
from models import  *
from datetime import datetime, date, timedelta
from flask_cors import CORS
from flask_restful import Api
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import matplotlib
matplotlib.use('agg')
import matplotlib.pyplot as plt
import seaborn as sns
import os

from flask_caching import Cache

from workers import create_celery_app

def create_app():
    app=Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///librarydb.sqlite3"
    app.config['SECRET_KEY'] = "my_secret_key"
    app.config['UPLOAD_FOLDER'] = './static/upload'
    app.config["JWT_SECRET_KEY"] = "secret-key"  
    app.config["JWT_ACCESS_TOKEN_EXPIRES"] = timedelta(days=1)
    app.config["REDIS_URL"] = 'redis://localhost:6379'
    app.config["CACHE_TYPE"] = 'RedisCache'
    app.config["CACHE_REDIS_URL"] = "redis://localhost:6379/3"
    app.config["CACHE_REDIS_HOST"] = ""
    app.config["CACHE_DEFAULT_TIMEOUT"] = 100 # By default, cache timeout is 100 seconds
    app.config["CACHE_KEY_PREFIX"] = "cache_key/"
    api=Api(app)
    CORS(app)
    jwt = JWTManager(app)
    jwt.init_app(app)
    db.init_app(app)
    cache = Cache(app)
    cel_app = create_celery_app(app)
    app.app_context().push()
    return app, jwt, api, cel_app, cache


app, jwt, api, cel_app, cache = create_app()


# import the celery task
from celery_task import *

# Import the controllers
from controllers import *

# --------------API------------
from resources import *

api.add_resource(SectionAPI, "/api/section", "/api/section/<int:s_id>")
api.add_resource(BookAPI, "/api/book", "/api/book/<int:b_id>")
api.add_resource(AllSections, "/api/sections",)
api.add_resource(AllBooks, "/api/books",)
api.add_resource(All_Section_Books, "/api/section_books/<int:s_id>",)

# ----------------------------




if __name__=='__main__':
    app.run(debug=True)
    