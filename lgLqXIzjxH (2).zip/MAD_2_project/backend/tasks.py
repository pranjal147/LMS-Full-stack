from celery import shared_task
import time
import os
from mail import send_mail
from jinja2 import Template
from models import *

import csv 

from datetime import datetime, timedelta


@shared_task()
def send_daily_remainder():
    users = User.query.filter_by(role='user').all()
    tfha = datetime.now() - timedelta(hours=24)
    for user in users:
        # if user.last_logged_in<tfha: # if the user has not been visited the site for the last 24 hour ### send a email
        with open('templates/daily_remainder.html') as f:
            text_msg = Template(f.read())
            send_mail(user.email, "Remainder !!", text_msg.render(user = user.name))
        # else:
        #    pass
    

@shared_task()
def send_monthly_report():
    users = User.query.filter_by(role='user').all()
    for user in users:
        books_issues = user.bookissues
        books = []
        for b_i in books_issues:
            books.append(b_i)
            # current_month = datetime.now().month
            # current_year = datetime.now().year
            
            # # Check if the current month is January and the issue date month is December of the previous year
            # if current_month == 1 and b_i.date_of_issue.month == 12 and b_i.date_of_issue.year == current_year - 1:
            #     books.append(b_i)
            
            # elif b_i.date_of_issue.month == current_month-1 and b_i.date_of_issue.year == current_year:
            #     books.append(b_i)
                
        with open('templates/monthly_report.html') as f:
            text_msg = Template(f.read())
            send_mail(user.email, "Monthly Activity Report", text_msg.render(user = user.name, books=books))